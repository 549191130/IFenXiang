var util = require('../../utils/util.js');
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    //判断小程序的API，回调，参数，组件等是否在当前版本可用。
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    hasUserInfo: false,
    current: 1000,
    integral: 0,
    title: [
      '../../img/轮播1.jpg',
      '../../img/轮播2.jpg',
      '../../img/轮播3.jpg'
    ],
    latestList: []
  },

  handleChange({
    detail
  }) {
    this.setData({
      current: detail.key
    });
  },
  // 点击资源分类
  tap: function(event) {
    var kindid = event.currentTarget.dataset.kindid;
    wx.navigateTo({
      url: '../list/list?kindid=' + kindid
    })
  },
  // 点击最新发布
  excahnge: function(event) {
    wx.navigateTo({
      url: '../exchange/exchange?resource=' + JSON.stringify(event.currentTarget.dataset.detail)
    })
  },
  // 签到
  sign: function(event) {
    var that = this;
    if (app.globaData.userInfo != null) {
      util.getAjaxRet('post', app.globaData.url + '/user/sign', {
        'openid': app.globaData.userInfo.openid
      }, function(ret) {
        if (ret.success) {
          if (ret.data.flag) {
            //全局设置integral
            app.globaData.integral = ret.data.integral;
            //设置本page 的integral
            that.setData({
              integral: ret.data.integral
            });
            wx.showToast({
              title: '签到成功!',
              icon: 'success',
              duration: 3000
            })
          } else {
            wx.showToast({
              title: '今日已签到!',
              icon: 'none',
              duration: 3000
            })
          }
        }
      });
    } else {
      wx.showToast({
        title: '请重新进入小程序!',
        icon: 'none',
        duration: 3000
      });
    }
  },

  // 随机签到
  signRandom: function(event) {
    var that = this;
    if (app.globaData.userInfo != null) {
      util.getAjaxRet('post', app.globaData.url + '/user/signRandom', {
        'openid': app.globaData.userInfo.openid
      }, function(ret) {
        if (ret.success) {
          if (ret.data.flag) {
            //全局设置integral
            app.globaData.integral = ret.data.integral;
            //设置本page 的integral
            that.setData({
              integral: ret.data.integral
            });
            wx.showToast({
              title: '漂亮:' + ret.data.randomIntegral + '积分',
              icon: 'success',
              duration: 3000
            })
          } else {
            wx.showToast({
              title: '今日已幸运签!',
              icon: 'none',
              duration: 3000
            })
          }
        }
      });
    } else {
      wx.showToast({
        title: '请重新进入小程序!',
        icon: 'none',
        duration: 3000
      });
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    // 标题 分类
    util.getAjaxRet('post', app.globaData.url + '/resourceskind/getAllResourcesKinds', {}, function(res) {
      if (res.success) {
        that.setData({
          title: res.data
        });
      }
    });
    // 最新发布
    util.getAjaxRet('post', app.globaData.url + '/resources/latest', {}, function(res) {
      if (res.success) {
        that.setData({
          latestList: res.data
        });
      }
    });
  },

  // 授权登录按钮
  bindGetUserInfo: function(e) {
    var that = this;
    if (e.detail.userInfo) {
      //用户按了允许授权按钮
      wx.request({
        url: app.globaData.url + '/user/add',
        method: 'post',
        data: {
          openid: app.globaData.userInfo.openid,
          nickName: e.detail.userInfo.nickName,
          avatarUrl: e.detail.userInfo.avatarUrl,
          province: e.detail.userInfo.province,
          city: e.detail.userInfo.city
        },
        header: { "Content-Type": "application/x-www-form-urlencoded" },
        success: function(res) {
          if (res.data.success){
            wx.showTabBar();//显示底部
            that.setData({
              hasUserInfo: true
            });
          }else{
            wx.showTabBar();
            that.setData({
              hasUserInfo: false
            });
          }
        }
      });
    } else {
      //用户按了拒绝按钮
      wx.showModal({
        title: '警告',
        content: '您点击了拒绝授权，不能更好体验小程序!!!',
        success: function(res) {
          if (res.cancel) {
            
          }else{
            wx.showTabBar();//显示底部
            that.setData({
              hasUserInfo: true
            });
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;

    if (app.globaData.userInfo.openid) {
      that.setData({
        integral: app.globaData.userInfo.integral
      });
      if (app.globaData.userInfo.nickname != "" || app.globaData.userInfo.nickname != null) {
        that.setData({
          hasUserInfo: true
        });
        wx.showTabBar();//显示底部
      }
    } else {
      // 由于app.js中的 saveOrGetUser 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.employIdCallback = userInfo => {
        that.setData({
          integral: userInfo.integral
        });
        if (userInfo.nickname != "" || userInfo.nickname != null) {
          that.setData({
            hasUserInfo: true
          });
          wx.showTabBar();//显示底部
        }
      }
    }

    // 获取用户当前积分
    wx.request({
      method: 'post',
      url: app.globaData.url + '/user/getUserByOpenId',
      data: {
        'openid': app.globaData.userInfo.openid
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success: function(res) {
        that.setData({
          integral: res.data.data.integral
        });
      }
    });
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(options) {
    // if (options.from === 'button') {
    //   // 来自页面内转发按钮
    //   console.log(options.target)
    // }
    // return {
    //   //## 此为转发页面所显示的标题
    //   title: '转发测试', 
    //   //## 此为转发页面的描述性文字
    //   desc: '江湖救急，还请贵人伸手相助啊!',
    //   //## 此为转发给微信好友或微信群后，对方点击后进入的页面链接，可以根据自己的需求添加参数
    //   path: 'pages/index/index',
    //   //## 转发操作成功后的回调函数，用于对发起者的提示语句或其他逻辑处理
    //   success: function (res) {
    //     //这是我自定义的函数，可替换自己的操作
    //     debugger;
    //   },
    //   //## 转发操作失败/取消 后的回调处理，一般是个提示语句即可
    //   fail: function () {
    //     debugger;
    //   }
    // }
  }
})