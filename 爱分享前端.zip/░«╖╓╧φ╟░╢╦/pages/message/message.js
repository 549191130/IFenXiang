var util = require('../../utils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    textAreaVal:'',//评论框的值
    messageList: [], //评论列表数据
    pageNumber: 1,
    pageSize: 15,
    searchLoadingComplete: false //是否加载完毕(所有数据)
  },
  formSubmit: function(e) {
    var that = this;
    var content = e.detail.value.content;
    content = content.trim();
    if (content == "") {
      wx.showToast({
        title: '内容不能为空',
        icon: 'none',
        duration: 2000,
        mask: true
      });
      return;
    }
    if (app.globaData.userInfo) {
      var openid = app.globaData.userInfo.openid;
      var message = {};
      message['openid'] = openid;
      message['content'] = content;
      util.getAjaxRet('post', app.globaData.url + '/message/addMessage', {
        'message': JSON.stringify(message)
      }, function(ret) {
        that.setData({
          textAreaVal:''
        });
        if (ret.flag) {
          wx.showToast({
            title: '请等待审核!',
            icon: 'success',
            duration: 2000
          });
        } else {
          that.setData({
            textAreaVal: ''
          });
          wx.showToast({
            title: '评论失败!',
            icon: 'none',
            image: '',
            duration: 2000,
            mask: true,
            success: function(res) {},
            fail: function(res) {},
            complete: function(res) {},
          })
        }
      });
    } else {
      wx.showToast({
        title: '请重新登录小程序',
        icon: 'loading',
        image: '',
        duration: 3000,
        mask: true,
        success: function(res) {},
        fail: function(res) {},
        complete: function(res) {},
      })
    }
  },
  searchScrollLower: function() {
    var that = this;
    if (!that.data.searchLoadingComplete) {
      util.getAjaxRet('get', app.globaData.url + '/message/pageMessage', {
        'pageNumber': that.data.pageNumber,
        'pageSize': that.data.pageSize
      }, function(ret) {
        if (ret.flag) {
          var list = [];
          list = that.data.messageList;
          if (ret.data.list.length < that.data.pageSize) {
            that.setData({
              searchLoadingComplete: true,
              messageList: list.concat(ret.data.list)
            });
          } else {
            that.setData({
              messageList: list.concat(ret.data.list),
              pageNumber: that.data.pageNumber + 1
            });
          }
        } else {
          wx.showToast({
            title: '请求数据失败!',
            icon: 'none',
            image: '',
            duration: 2000
          });
        }
      });
    } else {
      wx.showToast({
        title: '已加载所有留言!',
        icon: 'none',
        duration: 2000
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    util.getAjaxRet('get', app.globaData.url + '/message/pageMessage', {
      'pageNumber': that.data.pageNumber,
      'pageSize': that.data.pageSize
    }, function(ret) {
      if (ret.flag) {
        var list = [];
        list = that.data.messageList;
        if (ret.data.list.length < that.data.pageSize) {
          that.setData({
            searchLoadingComplete: true
          });
        }
        that.setData({
          messageList: list.concat(ret.data.list),
          pageNumber: that.data.pageNumber + 1
        });
      } else {
        wx.showToast({
          title: '请求数据失败!',
          icon: 'none',
          image: '',
          duration: 2000
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})