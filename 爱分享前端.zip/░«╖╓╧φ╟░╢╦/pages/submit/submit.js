var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },
  inputChange:function(e){
    
  },
  formSubmit(e) {
    var subValue = e.detail.value;
    if (subValue.resourcesintroduction == null || subValue.resourceslink==null || subValue.resourcesname==null || subValue.resourcespassword==null){
      wx.showToast({
        title: '请填写所有内容!',
        icon: 'none',
        duration: 3000
      });
      return false;
    }
    if (app.globaData.userInfo) {
      var openId = app.globaData.userInfo.openid;
      wx.request({
        url: app.globaData.url + '/submit/submit',
        method: 'post',
        data: {
          subValue: JSON.stringify(subValue),
          openId: openId
        },
        header: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        success: function(ret) {
          if (ret.data.success) {
            wx.showToast({
              title: '提交资源成功!',
              icon: 'success',
              duration: 1000
            });
            setTimeout(function () { 
              wx.reLaunch({
                url: '../account/account',
              })
            },1000);
          } else {
            wx.showToast({
              title: '提交资源失败!',
              icon: 'none',
              duration: 3000
            })
          }
        },
        fail: function() {
          wx.showToast({
            title: '提交资源失败!',
            icon: 'none',
            duration: 3000
          })
        }
      })
    }else{
      wx.showToast({
        title: '重新进入小程序!',
        icon: 'none',
        duration: 3000
      });
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
   
  },
  
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})