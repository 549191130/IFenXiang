var app = getApp();
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    resourceid: '',
    needIntegral: '',
    name: '',
    introduce: ''
  },
  exchange: function(event) {
    // 用户兑换资源,先判断用户积分是否够用,够用则可以正常兑换,否则弹出提示
    if (app.globaData.userInfo!=null) {
      var openId = app.globaData.userInfo.openid;
      var resourceId = event.currentTarget.dataset.resourceid;
      var needintegral = event.currentTarget.dataset.needintegral;
      util.getAjaxRet('post',app.globaData.url + "/exchange/exchange", {
        opneId: openId,
        resourcesId: resourceId,
        needIntegral: needintegral
      }, function(res) {
        if (res.flag) {
          //兑换成功才会减积分
          if (res.msg.indexOf('兑换成功')!=-1){
            app.globaData.userInfo.integral = app.globaData.userInfo.integral - needintegral;
          }
          wx.showToast({
            title: res.msg,
            icon: 'success',
            duration: 1000
          });
          setTimeout(function(){
            wx.redirectTo({
              url: '../myExchange/myExchange',
            })
          },1000);
        } else {
          wx.showToast({
            title: res.msg,
            icon:'none',
            duration:3000
          });
        }
      });
    }else{
      wx.showToast({
        title: '请重新进入小程序!',
        icon:'none',
        duration:3000
      });
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // disklink: "资源链接287"
    // diskpassword: "资源密码287"
    // introduce: "资源介绍287"
    // kindid: 3
    // name: "大数据287"
    // needintegral: 288
    // photo: "图片路径287"
    // publish: "2019-1-8"
    // resourcesid: 891
    // state: 1
    var resource = JSON.parse(options.resource);
    var resourceid = resource.resourcesid;
    var needIntegral = resource.needintegral;
    var name = resource.name;
    var introduce = resource.introduce;
    this.setData({
      resourceid: resourceid,
      needIntegral: needIntegral,
      name: name,
      introduce: introduce
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})