var util = require('./utils/util.js');
App({
  globaData: {
    url: 'https://www.aipanysys.com/IFenXiang',
    userInfo: null
  },
  /**
   * 当小程序初始化完成时，会触发 onLaunch（全局只触发一次）
   */
  onLaunch: function() {
    //隐藏底部
    wx.hideTabBar();

    var that = this;
    var userInfo = this.globaData.userInfo;
    if (userInfo == null) {
      wx.login({
        success: function (ret) {
          if (ret.code) {
            util.getAjaxRet("post", that.globaData.url + "/user/saveOrGetUser", {
              'code': ret.code
            }, function (ret) {
              if (ret.success) {
                that.globaData.userInfo = JSON.parse(ret.data);
                //由于这里是网络请求，可能会在 Page.onLoad 之后才返回
                // 所以此处加入 callback 以防止这种情况
                if (that.employIdCallback) {
                  that.employIdCallback(ret.data);//ret.data是一个用户的所有信息
                }
              } else {
                wx.showToast({
                  title: '请重新进入小程序!',
                  icon: 'none',
                  duration: 3000
                })
              }
            });
          }
        }
      });
    }
  },

  /**
   * 当小程序启动，或从后台进入前台显示，会触发 onShow
   */
  onShow: function(options) {
    
    
  },
  /**
   * 当小程序从前台进入后台，会触发 onHide
   */
  onHide: function() {

  },

  /**
   * 当小程序发生脚本错误，或者 api 调用失败时，会触发 onError 并带上错误信息
   */
  onError: function(msg) {

  }
})